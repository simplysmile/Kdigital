//
//  SDKDemoAPIKey.h
//  SampleDaumMap
//
//  Created by ParkYoungjoo on 2014. 9. 15..
//
//

// http://dna.daum.net/apis/mmaps
static NSString *const kAPIKey = @"6f504f9b73ad280372b2aff0036b6f32";

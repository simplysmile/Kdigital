package net.daum.android.map.openapi.sampleapp.demos.runtimePermissions;

/**
 * Created by kris.shin on 11/13/15.
 *
 */
public interface AppPermissionCallbackHandler {
    void onPermissionGranted();
    void onPermissionDenied();
}

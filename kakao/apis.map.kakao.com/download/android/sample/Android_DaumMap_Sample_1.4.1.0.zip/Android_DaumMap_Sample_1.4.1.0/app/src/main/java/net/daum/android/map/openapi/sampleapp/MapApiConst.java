package net.daum.android.map.openapi.sampleapp;

/**
 * Created by pjh on 2014. 9. 15..
 */
public class MapApiConst {
	// http://developers.daum.net/console
    public static final String DAUM_MAPS_ANDROID_APP_API_KEY = "6f504f9b73ad280372b2aff0036b6f32";
}
